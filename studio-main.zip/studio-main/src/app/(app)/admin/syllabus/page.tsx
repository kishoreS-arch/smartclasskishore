import { SyllabusCard } from '@/components/dashboard/syllabus-card';

export default function AdminSyllabusPage() {
  return <SyllabusCard role="admin" />;
}
