import { TimetableCard } from '@/components/dashboard/timetable-card';

export default function AdminTimetablePage() {
  return <TimetableCard role="admin" />;
}
