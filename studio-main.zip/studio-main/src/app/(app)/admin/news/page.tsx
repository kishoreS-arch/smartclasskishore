import { NewsUpdatesCard } from '@/components/dashboard/news-updates-card';

export default function AdminNewsPage() {
  return <NewsUpdatesCard />;
}
