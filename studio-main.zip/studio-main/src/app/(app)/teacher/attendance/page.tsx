import { AttendanceCard } from '@/components/dashboard/attendance-card';

export default function TeacherAttendancePage() {
  return <AttendanceCard />;
}
