import { WeeklyTimetableCard } from '@/components/dashboard/weekly-timetable-card';

export default function TeacherTimetablePage() {
  return <WeeklyTimetableCard role="teacher" />;
}
