import { SyllabusCard } from '@/components/dashboard/syllabus-card';

export default function StudentSyllabusPage() {
  return <SyllabusCard role="student" />;
}
