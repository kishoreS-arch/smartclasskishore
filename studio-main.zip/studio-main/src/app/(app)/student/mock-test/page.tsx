import { MockTestCard } from '@/components/dashboard/mock-test-card';

export default function StudentMockTestPage() {
  return <MockTestCard />;
}
