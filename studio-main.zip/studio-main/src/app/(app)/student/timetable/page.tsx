import { WeeklyTimetableCard } from '@/components/dashboard/weekly-timetable-card';

export default function StudentTimetablePage() {
  return <WeeklyTimetableCard />;
}
