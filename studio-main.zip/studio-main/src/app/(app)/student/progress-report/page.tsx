import { ProgressCard } from '@/components/dashboard/progress-card';

export default function StudentProgressReportPage() {
  return <ProgressCard />;
}
