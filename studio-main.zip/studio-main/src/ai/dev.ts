import { config } from 'dotenv';
config();

import '@/ai/flows/ai-mock-test-feedback.ts';
import '@/ai/flows/ai-faq-chatbot.ts';
import '@/ai/flows/ai-exam-seating.ts';
